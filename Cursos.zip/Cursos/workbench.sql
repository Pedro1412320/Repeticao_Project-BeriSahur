DROP TABLE IF EXISTS aluno;
DROP TABLE IF EXISTS curso;

CREATE TABLE curso (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cargahoraria VARCHAR(100) NOT NULL
);

CREATE TABLE aluno (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    id_curso INT NOT NULL,
    CONSTRAINT FK_aluno_curso FOREIGN KEY (id_curso) REFERENCES curso(id)
);

INSERT INTO curso (nome, cargahoraria) VALUES ('Química', '8horas');
INSERT INTO curso (nome, cargahoraria) VALUES ('DesenvolvimentoSistemas', '8horas');
INSERT INTO curso (nome, cargahoraria) VALUES ('Adiministração', '8horas');

INSERT INTO aluno (nome, email, id_curso) VALUES ('Sans', 'light@saber.com', 1);
INSERT INTO aluno (nome, email, id_curso) VALUES ('béri', 'lucifer@hell.com', 2);
INSERT INTO aluno (nome, email, id_curso) VALUES ('sinitzyn', 'dawai@dawai.com', 2);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Gilbert', 'Miles@Troy.com', 3);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Yuri', 'Stalker@Hate.com', 1);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Tomcat', 'AIM54@Phoenix.com', 2);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Kamikaze', 'Granada@Japão.com', 3);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Shielder', 'desgraça@maldito.com', 1);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Rasonians', 'AK@SON.com', 2);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Menlo', 'WE30@brasil.com', 3);
INSERT INTO aluno (nome, email, id_curso) VALUES ('Dom Pedro de Alcântara Francisco Antônio João Carlos Xavier de Paula Miguel Rafael Joaquim José Gonzaga Pascoal Cipriano Serafim de Bragança e Bourbon', 'maisde2linhas@eunaoleio.com', 2);

-- 1. Listar todos os cursos
SELECT * FROM curso;

-- 2. Listar todos os alunos
SELECT * FROM aluno;

-- 3. Mostrar somente o nome e o e-mail dos alunos
SELECT nome, email FROM aluno;

-- 4. Buscar um aluno específico pelo id (Exemplo: id = 1)
SELECT * FROM aluno WHERE id = 1;

-- 5. Listar os alunos de um determinado curso (Exemplo: "DesenvolvimentoSistemas")
SELECT 
    aluno.id, 
    aluno.nome AS aluno_nome, 
    aluno.email, 
    curso.nome AS curso_nome
FROM aluno
INNER JOIN curso ON aluno.id_curso = curso.id
WHERE curso.nome = 'DesenvolvimentoSistemas';