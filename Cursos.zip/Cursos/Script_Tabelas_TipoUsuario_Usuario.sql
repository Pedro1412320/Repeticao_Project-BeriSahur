
--
-- Tabela tipousuario
--

CREATE TABLE tipousuario (
  id int NOT NULL AUTO_INCREMENT,
  descricao varchar(100) NOT NULL,
  PRIMARY KEY (id)
);

--
-- Dados tipousuario
--

INSERT INTO tipousuario (descricao) VALUES ('Administrador');
INSERT INTO tipousuario (descricao) VALUES ('Usuário');

--
-- Tabela usuario
--

CREATE TABLE usuario (
  id int NOT NULL AUTO_INCREMENT,
  nome varchar(100) NOT NULL,
  email varchar(100) NOT NULL,
  telefone varchar(15) DEFAULT NULL,
  cpf varchar(11) DEFAULT NULL,
  datanascimento date DEFAULT NULL,
  login varchar(20) NOT NULL,
  senha varchar(50) NOT NULL,
  datacadastro datetime DEFAULT NULL,
  dataultimoacesso datetime DEFAULT NULL,
  id_tipousuario int DEFAULT NULL,
  PRIMARY KEY (id),
  KEY FK_usuario_tipousuario (id_tipousuario),
  CONSTRAINT FK_usuario_tipousuario FOREIGN KEY (id_tipousuario) REFERENCES tipousuario (id)
);

--
-- Dados usuario
--

INSERT INTO usuario (nome, email, telefone, cpf, datanascimento, login, senha, datacadastro, id_tipousuario) 
VALUES ('Maicon','maicon.batista@cps.sp.gov.br','17991195373','00000000000','1988-08-07','admin','123456',NOW(),1);

INSERT INTO usuario (nome, email, telefone, cpf, datanascimento, login, senha, datacadastro, id_tipousuario) 
VALUES ('Hugo','hugo.marinho@aluno.cps.sp.gov.br','17991190000','00000000001','2010-05-28','hugo.marinho','123456',NOW(),2);

INSERT INTO usuario (nome, email, telefone, cpf, datanascimento, login, senha, datacadastro, id_tipousuario) 
VALUES ('Odair Mialich','odair.mialich@cps.sp.gov.br','17991190001','00000000002','2010-05-28','odair.mialich','123456',NOW(),1);
